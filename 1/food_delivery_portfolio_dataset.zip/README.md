# Food Delivery Analytics — Portfolio Dataset

Синтетический реалистичный датасет для Python / Google Colab.

Файлы:
- orders.csv — заказы;
- customers.csv — клиенты и клиентские агрегаты;
- products.csv — ассортимент;
- marketing_daily.csv — маркетинговые показатели по каналам и дням;
- food_delivery_master.csv — объединённый order-level файл;
- README.md — описание.

Подходит для:
EDA, очистки данных, KPI, выручки, среднего чека, маржи, скидок,
repeat rate, RFM, LTV, ABC, доставки, рейтингов, каналов,
CTR, CPL, CPA, ROI/ROMI и когортного анализа.

Данные синтетические. Маркетинговые и операционные показатели сгенерированы
для демонстрации аналитических методов; в портфолио это нужно указать явно.

Рекомендуемые формулы:
- AOV = выручка / доставленные заказы
- Margin % = gross_profit / order_total
- CPL = spend / leads
- CPA = spend / new_customers
- LTV (упрощённо) = суммарная выручка клиента за период
- ROI/ROMI = (атрибутированная выручка - spend) / spend
